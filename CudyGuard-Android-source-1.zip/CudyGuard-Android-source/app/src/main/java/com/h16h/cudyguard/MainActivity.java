package com.h16h.cudyguard;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.text.InputType;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
 LinearLayout root;
 EditText routerUrl;
 TextView status;
 int green = Color.rgb(20,125,80);
 GradientDrawable bg(int color,int radius){ GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d; }
 TextView text(String s,int size,int color){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setPadding(12,10,12,10); return t; }
 EditText input(String hint,int type){ EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setInputType(type); e.setPadding(18,12,18,12); e.setBackground(bg(Color.rgb(245,248,246),18)); return e; }
 Button button(String s){ Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(green,18)); return b; }
 void setup(String title){ ScrollView scroll=new ScrollView(this); root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,32,24,24); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(Color.rgb(247,250,248)); scroll.addView(root); setContentView(scroll); TextView brand=text("CUDY GUARD",27,green); brand.setTypeface(null,Typeface.BOLD); add(brand); add(text(title,19,Color.DKGRAY)); }
 void add(View v){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0,8,0,8); root.addView(v,p); }
 @Override public void onCreate(Bundle b){ super.onCreate(b); showLogin(); }
 void showLogin(){
  setup("تسجيل الدخول");
  EditText email=input("البريد الإلكتروني",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
  EditText pass=input("كلمة المرور",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
  add(email); add(pass);
  add(text("الدخول تجريبي في هذه النسخة، وغير مربوط بخدمة حسابات Firebase.",14,Color.DKGRAY));
  Button login=button("دخول للوحة التحكم"); add(login);
  login.setOnClickListener(v->{ if(email.getText().toString().trim().isEmpty()||pass.getText().length()<6) Toast.makeText(this,"أدخل البريد وكلمة مرور من 6 أحرف على الأقل",Toast.LENGTH_LONG).show(); else showDashboard(); });
 }
 void showDashboard(){
  setup("لوحة مراقبة الراوتر");
  status=text("لم يتم فحص الراوتر بعد",16,Color.rgb(180,100,20)); status.setBackground(bg(Color.WHITE,18)); add(status);
  routerUrl=input("عنوان الراوتر مثل http://192.168.1.1",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI); add(routerUrl);
  Button check=button("فحص الوصول إلى الراوتر"); add(check); check.setOnClickListener(v->checkRouter());
  Button back=button("تسجيل الخروج"); add(back); back.setOnClickListener(v->showLogin());
  add(text("الفحص يتحقق من الوصول إلى صفحة الراوتر فقط؛ ولا يثبت عمل الإنترنت أو يقرأ كل بيانات الراوتر.",12,Color.GRAY));
 }
 void checkRouter(){
  String address=routerUrl.getText().toString().trim();
  if(address.isEmpty()){ Toast.makeText(this,"اكتب عنوان الراوتر أولاً",Toast.LENGTH_SHORT).show(); return; }
  status.setText("جارٍ الفحص...");
  new Thread(()->{
   String result; HttpURLConnection c=null;
   try { String u=address; if(!u.startsWith("http://")&&!u.startsWith("https://")) u="http://"+u; c=(HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(4000); c.setReadTimeout(4000); c.setRequestMethod("GET"); int code=c.getResponseCode(); result="يمكن الوصول إلى واجهة الراوتر (HTTP "+code+"). هذا لا يعني أن الإنترنت يعمل."; }
   catch(Exception ex){ result="تعذّر الوصول. تأكد أنك متصل بشبكة الراوتر وأن العنوان صحيح."; }
   finally { if(c!=null)c.disconnect(); }
   final String r=result; runOnUiThread(()->status.setText(r));
  }).start();
 }
}
